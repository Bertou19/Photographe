<section>
    <div>
      <img class="background" src="background.jpg" alt="studio photo">
      <div class="home text-sm-center text-xs-center text-center">
        <h1 class="h1-index text-center">Charles Cantin-Photographe</h1>
        <img class="profil center-block p-2 text-center " src="photoProfil.jpg" alt="photo de profil">
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h2 class="title-section text-center p-4">Ma passion</h2>
          <p class="text-home">At vero eos et accusamus et iusto odio dignissimos ducimus</p>
          <p class="text-home">qui blanditiis praesentium voluptatum deleniti atque corrupti quos</p>
          <p class="text-home">dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>
          <button type="button" class="btn btn-dark mx-auto rounded-5 p-2 mb-5 rounded"><a href="contact.html"
              class="btn-contact">ME
              CONTACTER</a></button>
        </div>
      </div>
    </div>
  </section>